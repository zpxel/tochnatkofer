pkg update
pkg upgrade
pkg install python
pkg install python-pip
pip install pycryptodome
pkg install git
pkg install zip
termux-setup-storage
pkg install p7zip
cd
cd tochnat
chmod +x tochnat.py
python tochnat.py
